import 'package:flutter/material.dart';

class Routes {
  static final routes = <String, WidgetBuilder>{};


  
}
// This class useless for now...