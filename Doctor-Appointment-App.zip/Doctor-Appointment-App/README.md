# Getting Started
This project written wiht Flutter.
!!YOU SHOULD ADD YOUR OWN FİREBASE ACCOUNT WHEN YOU FORK OR DOWNLOAD THE PROJECT, OTHERWISE APP DOES NOT WORK!!

## Initial commit includes

*Welcome page design,
*Register page design,
*Some validation code(validation_mixin.dart)


## Between Initial and 05_May_2019

*User and doctor model added,
*Firebase sync,
*Implementation for register and login state

## 06_May_2019

*User home page design,
*Data transfer algorithm between 2 screens

## 06_May_2019 v2

*Admin page design,
*Admin model added,
*Fixed some code

## 06_May_2019 v3

*Hospital and section model added,
*"Add doctor" method implementation for admin

## 06_May_2019 v5

*MakeAppointmentPage design,(have some needed),
*Add a search function on dbHelper

## 07_May_2019 v1

*Some changes on addDoctorPage but it has some bugs
*TODO : fix the bugs

## 08_May_2019 v1

*Added to MakeAppointment Page
*TODO : code the backend

*Added to List of Appointment History Page
*TODO : dev to backend

## 09_May_2019 v1
*Added to deldata and updateData class
*TODO: The function should be tested in updateData

## 09_May_2019 v1.1
*added to saveSection function

## 09_May_2019 v2

*Fixed the bugs from 07_May_2019 v1,
*All function about addDoktorPage are work and stable

## 09_May_2019 v3

*AddSectionPage backend implementation added, has some lack

## 09_May_2019 v4

*fixed the deficiences on 09_May_2019 v3

## 10_May_2019 v1

*All add and update function work and stable for adminHomePage,
*Implement some screen navigator detail

## 10_May_2019 v2
 
 *DeleteDoctor method added,
 *Fixed a mistake on addDoctorPage.dart

 ## 11_May_2019 v1

 *DeleteSection and deleteHospital page and method added,
 *All delete function work and stable

 ## 17_May_2019 v1

 *Build an algorithm to add an appointment on database,
 *AddAppointmentPage design added

 ## 17_May_2019 v2

 *doctorHomePage, updateDoctorPass, showActiveAppo and updateUserInfo pages added,
 *I found some bugs on appointment algorithm - TODO: fix the bugs,
 *Some changes on other pages,
 *TODO : Need to search about data transfer normalization

 ## 23_May_2019 v1

 *I fix the bugs from 17_May_2019 v2,
 *All activeAppointment and pastAppointment methods work and stable,
 *AppointmentTimesPage added,
 *Some changes on other pages,

 ## 23_May_2019 v2

 *Some logical corrections on deleteHospitalPage, deleteSectionPage and makeAppointment.dart

 ## 24_May_2019 v1

 *showUserFavList page added,
 *favListModel added,
 *closeAppointment function added for admin
 *Some changes on appointmentHistory, adminModel and all dbHelper functions

 ## 24_May_2019 v2

 *"Open/Close Appointment Hours" functions added for Admin,
 *Some field added on addDoctorPage


