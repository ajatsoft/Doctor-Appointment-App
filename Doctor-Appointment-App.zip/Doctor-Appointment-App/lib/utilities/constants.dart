class Constants {
  static const String ROUTES_USER_HOME_PAGE = "/userHomePage";
  static const String ROUTES_REGISTER_PAGE = "/registerPage";
  static const String ROUTES_DOKTOR_HOME_PAGE = "/doktorHomePage";
  static const String ROUTES_ADMIN_HOME_PAGE = "/adminHomePage";
}
// This class useless for now...